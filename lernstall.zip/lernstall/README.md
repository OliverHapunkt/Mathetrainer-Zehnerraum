# Sternchens Lern-Stall

Interaktiver Lerntrainer mit Pony-Motivation. Läuft komplett im Browser, ohne Server, ohne Konto.

## Eigenschaften
- Name wird beim ersten Start abgefragt und nur im Browser (localStorage) gespeichert
- Fortschritt, Hufeisen und Fehlerstatistik bleiben lokal auf dem Gerät
- Keine externen Dienste: Schriften liegen in `fonts/` (SIL OFL), keine Tracker, keine Google-Anfragen
- Aufbau für mehrere Themen: pro Thema eine Datei in `js/topics/`

## Auf GitHub Pages veröffentlichen
1. Neues Repository anlegen und den Inhalt dieses Ordners hochladen (`index.html` muss im Hauptverzeichnis liegen)
2. Im Repository: **Settings → Pages**
3. **Source:** „Deploy from a branch“, Branch `main`, Ordner `/ (root)`, speichern
4. Nach ca. 1 Minute erreichbar unter `https://<benutzername>.github.io/<repo-name>/`
5. Auf Tablet oder Handy: Seite öffnen und „Zum Home-Bildschirm“ hinzufügen

Hinweis: Fortschritt gilt pro Gerät und Browser. Ein Wechsel des Geräts beginnt von vorn.

## Neues Thema hinzufügen
1. `js/topics/_vorlage.js` kopieren, z. B. nach `js/topics/deutsch-klasse2.js`
2. Thema, Übungsplätze, Lernkarten und Aufgaben-Generatoren anpassen (alles in der Vorlage erklärt)
3. In `index.html` eine Zeile ergänzen: `<script src="js/topics/deutsch-klasse2.js"></script>`
4. Sobald mehr als ein Thema geladen ist, erscheinen oben Reiter zum Umschalten

Stations-IDs müssen über alle Themen eindeutig sein (Präfix mit dem Themen-Kürzel).

## Struktur
- `index.html` – Einstieg und Skript-Reihenfolge
- `css/style.css` – Aussehen (Hell/Dunkel automatisch)
- `js/core.js` – Kern: Speicher, Startbildschirm, Übungsablauf, Pony, Themen-Register
- `js/visuals-math.js` – Mathe-Grafiken (Rechenstrich, Streifenmodell, Hunderterfeld)
- `js/topics/mathe-klasse2.js` – Thema „Mathe Klasse 2“
- `js/topics/_vorlage.js` – Vorlage für neue Themen (nicht eingebunden)
- `js/main.js` – Startet die App

## Lokal testen
`index.html` per Doppelklick öffnen. Alternativ: `python3 -m http.server` im Ordner.
